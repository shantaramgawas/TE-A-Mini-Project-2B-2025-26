export { default } from './Insights';
