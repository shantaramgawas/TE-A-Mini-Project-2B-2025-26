export { default } from './Detection';
