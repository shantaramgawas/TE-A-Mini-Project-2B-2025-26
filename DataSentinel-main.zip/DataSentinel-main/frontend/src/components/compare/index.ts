export { default } from './Compare';
